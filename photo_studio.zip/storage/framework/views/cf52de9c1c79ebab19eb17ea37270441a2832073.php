<!-- ======= Header ======= -->
<header id="header" class="<?php echo e(request()->is('/') ? 'header-transparent' : ''); ?>">
    <div class="container">

        <div id="logo" class="pull-left">
            <a href="<?php echo e(route('view.user.home')); ?>"><img src="<?php echo e(asset('user_assets/img/logo.png')); ?>" width="42px" style="max-height: 40px" alt=""></a>
            <!-- Uncomment below if you prefer to use a text logo -->
            <!--<h1><a href="#hero">Regna</a></h1>-->
        </div>

        <nav id="nav-menu-container">
            <ul class="nav-menu">
                <li class="<?php echo e(request()->is('/') ? 'menu-active' : ''); ?>"><a href="<?php echo e(route('view.user.home')); ?>">Home</a></li>
                <li class="<?php echo e(request()->is('shop') ? 'menu-active' : ''); ?>"><a href="<?php echo e(route('view.user.shop')); ?>">Shop</a></li>
                <li class="<?php echo e(request()->is('portfolio') ? 'menu-active' : ''); ?>"><a href="<?php echo e(route('view.user.portfolio')); ?>">Portfolio</a></li>
                <li class="<?php echo e(request()->is('about_us') ? 'menu-active' : ''); ?>"><a href="<?php echo e(route('view.user.about_us')); ?>">About Us</a></li>
                <li class="<?php echo e(request()->is('contact_us') ? 'menu-active' : ''); ?>"><a href="<?php echo e(route('view.user.contact_us')); ?>">Contact Us</a></li>
                <?php if(auth()->guard()->check()): ?>
                <li><a href="<?php echo e(route('view.home')); ?>">Dashboard</a></li>    
                <?php endif; ?>
                
                <?php if(auth()->guard()->guest()): ?>
                    <li class="<?php echo e(request()->is('login') ? 'menu-active' : ''); ?>"><a href="<?php echo e(route('login')); ?>">Login</a></li>
                <?php endif; ?>
            </ul>
        </nav><!-- #nav-menu-container -->
    </div>
</header><!-- End Header -->
<?php /**PATH C:\Users\zaenur\Documents\dev\freelance\photo_studio\resources\views/partials/user-header.blade.php ENDPATH**/ ?>