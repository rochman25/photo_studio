
<?php $__env->startSection('user_pages'); ?>
    <!-- ======= Hero Section ======= -->
    <section id="hero">
        <div class="" style="height:100vh" data-aos="zoom-in" data-aos-delay="100">
            
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <?php $__currentLoopData = $heros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($index); ?>" class="active"></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
                <div class="carousel-inner">
                    <?php $__empty_1 = true; $__currentLoopData = $heros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="carousel-item <?php if($index == 0): ?> active <?php endif; ?>">
                            <img class="d-block w-100" style="height: 100vh" src="<?php echo e(asset($item->file_url)); ?>"
                                alt="First slide">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="carousel-item active">
                            <img class="d-block w-100" style="height: 100vh" src="<?php echo e(asset('img/hero_1.png')); ?>"
                                alt="First slide">
                        </div>
                    <?php endif; ?>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </section><!-- End Hero Section -->

    <main id="main">

        <!-- ======= Portfolio Section ======= -->
        <section id="portfolio" class="portfolio">
            <div class="" data-aos="fade-up">
                <div class="section-header">
                    <h3 class="section-title">Portfolio</h3>
                    <p class="section-description">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                        accusantium doloremque</p>
                </div>

                <div class="row" data-aos="fade-up" data-aos-delay="200">
                    <?php $__empty_1 = true; $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                            <img src="<?php echo e(asset($item->file_url)); ?>" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><?php echo e($item->nama); ?></h4>
                                <p><?php echo e($item->caption); ?></p>
                                <a href="<?php echo e(asset($item->file_url)); ?>" data-gall="portfolioGallery"
                                    class="venobox preview-link" title="App 1"><i class="bx bx-plus"></i></a>
                                <a href="<?php echo e(route('view.user.portfolio.detail',$item->id)); ?>" class="details-link" title="More Details"><i
                                        class="bx bx-link"></i></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-lg-12 portfolio-item">
                            <div class="section-header">
                                <p class="section-description"><?php echo e('Portfolio Masih Kosong.'); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </section><!-- End Portfolio Section -->

        <!-- ======= About Section ======= -->
        <section id="about">
            <div class="container" data-aos="fade-up">
                <div class="row about-container">

                    <div class="col-lg-6 content order-lg-1 order-2">
                        <h2 class="title">Few Words About Us</h2>
                        <p>
                            <?php echo e($aboutUs); ?>

                        </p>

                    </div>

                    <div class="col-lg-6 order-lg-2 order-1" data-aos="fade-left" data-aos-delay="100">
                        <img src="<?php echo e(asset($photoAboutUs)); ?>" class="img-fluid" alt="">
                    </div>
                </div>

            </div>
        </section><!-- End About Section -->
    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zaenur\Documents\dev\freelance\photo_studio\resources\views/pages/user/home.blade.php ENDPATH**/ ?>