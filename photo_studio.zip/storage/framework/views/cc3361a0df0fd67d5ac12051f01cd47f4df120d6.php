<div class="kt-container kt-container--fluid ">
    <div class="kt-footer__copyright">
        2021&nbsp;&copy;&nbsp;<a href="http://keenthemes.com/metronic" target="_blank" class="kt-link"></a>
    </div>
</div>
<?php /**PATH C:\Users\zaenur\Documents\dev\freelance\photo_studio\resources\views/partials/footer.blade.php ENDPATH**/ ?>