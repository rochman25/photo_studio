
<?php $__env->startPush('user_styles'); ?>
    <style>
        [data-toggle="collapse"] .fa:before {
            content: "\f139";
        }

        [data-toggle="collapse"].collapsed .fa:before {
            content: "\f13a";
        }

    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('user_pages'); ?>
    <main id="main">

        <!-- ======= Breadcrumbs Section ======= -->
        <section class="breadcrumbs">
            <div class="container">

                <div class="d-flex justify-content-between align-items-center">
                    <h2>Shop</h2>
                    <ol>
                        <li><a href="<?php echo e(route('view.user.home')); ?>">Home</a></li>
                        <li>Shop</li>
                    </ol>
                </div>

            </div>
        </section><!-- End Breadcrumbs Section -->

        <section class="inner-page pt-4">
            <div class="container">
                <div class="row mb-5">
                    <div class="col-lg-4 mb-3">
                        <div class="card" style="">
                            <div class="card-header">
                                <h4>Categories</h4>
                            </div>
                            <ul class="list-group list-group-flush">
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li class="list-group-item"><a
                                            href="<?php echo e(route('view.user.shop.categories', $item->slug)); ?>"><?php echo e($item->nama); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li class="list-group-item"><?php echo e('Kategori Belum Ada'); ?></li>
                                <?php endif; ?>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="card" style="">
                            <div class="card-header">
                                <h4>Products</h4>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-4">
                                    <div class="card mb-4 shadow-sm">
                                        <img class="card-img-top" src="<?php echo e(asset($item->thumbnail)); ?>" alt="Card image cap">
                                        <div class="card-body">
                                            <p class="card-text">
                                                <h4 style="font-weight: bold">
                                                    <?php echo e($item->nama); ?>

                                                </h4>
                                                Rp. <?php echo number_format($item->harga, 0, ',', '.'); ?>
                                            </p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <a href="<?php echo e(route('view.user.shop.detail', str_replace(" ","-",$item->nama))); ?>" type="button"
                                                        class="btn btn-sm btn-outline-secondary">Pesan</a>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-md-12">
                                    <div class="card mb-4 shadow-sm">
                                        <div class="card-body">
                                            <p class="card-text"><?php echo e('Oops Produk belum ditambahkan'); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </section>

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zaenur\Documents\dev\freelance\photo_studio\resources\views/pages/user/shop/index.blade.php ENDPATH**/ ?>