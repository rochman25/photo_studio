
<?php $__env->startSection('user_pages'); ?>
    <main id="main">

        <!-- ======= Breadcrumbs Section ======= -->
        <section class="breadcrumbs">
            <div class="container">
                <div class="d-flex justify-content-between align-items-center">
                    <h2>Portfolio</h2>
                    <ol>
                        <li><a href="<?php echo e(route('view.user.home')); ?>">Home</a></li>
                        <li>Portfolio</li>
                    </ol>
                </div>
            </div>
        </section><!-- End Breadcrumbs Section -->

        <section class="portfolio-details">
            <div class="">
                <!-- ======= Portfolio Section ======= -->
                <div id="portfolio" class="portfolio">
                    <div class="container" data-aos="fade-up">
                        

                        <div class="row" data-aos="fade-up" data-aos-delay="200">
                            <?php $__empty_1 = true; $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-lg-12 col-md-12 portfolio-item filter-app">
                                    <img src="<?php echo e(asset($item->file_url)); ?>" class="img-fluid" alt="">
                                    <div class="portfolio-info">
                                        <h4><?php echo e($item->nama); ?></h4>
                                        <p><?php echo e($item->caption); ?></p>
                                        <a href="<?php echo e(public_path($item->file_url)); ?>" data-gall="portfolioGallery"
                                            class="venobox preview-link" title="App 1"><i class="bx bx-plus"></i></a>
                                        <a href="<?php echo e(route('view.user.portfolio.detail', $item->id)); ?>"
                                            class="details-link" title="More Details"><i class="bx bx-link"></i></a>
                                    </div>
                                </div>
                                <?php echo e($portfolios->links()); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-lg-12 col-md-12 portfolio-item filter-app">
                                    <p class="section-description" style="text-align: center"><?php echo e('Portfolio Masih Kosong.'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                    </div>
                </div><!-- End Portfolio Section -->
            </div>
        </section>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zaenur\Documents\dev\freelance\photo_studio\resources\views/pages/user/etc/portfolio.blade.php ENDPATH**/ ?>