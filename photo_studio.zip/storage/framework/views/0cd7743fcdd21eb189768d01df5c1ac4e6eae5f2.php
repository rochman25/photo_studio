<!-- ======= Footer ======= -->


    <!-- Footer -->
    <footer id="footer" class="footer" style="padding-bottom:0px">
      <!-- Grid container -->
      <div class="p-4">
        <!--Grid row-->
        <div class="row">
          <!--Grid column-->
          <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
            <h5 class="text-uppercase"><?php echo e($personalisasi[0]['P001']['value']); ?></h5>
  
            <p>
              <?php echo e($personalisasi[0]['P004']['value']); ?> <br />
              <?php echo e($personalisasi[0]['P006']['value']); ?> <br />           
              <?php echo e($personalisasi[0]['P005']['value']); ?>            
            </p>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Social Media</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="<?php echo e($personalisasi[0]['P007']['value']); ?>" class="text-white">Facebook</a>
              </li>
              <li>
                <a href="<?php echo e($personalisasi[0]['P008']['value']); ?>" class="text-white">Instagram</a>
              </li>
              <li>
                <a href="<?php echo e($personalisasi[0]['P009']['value']); ?>" class="text-white">Twitter</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          
          <!--Grid column-->
        </div>
        <!--Grid row-->
      </div>
      <!-- Grid container -->
  
      <!-- Copyright -->
      <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
        © 2021 Copyright
        
      </div>
      <!-- Copyright -->
    </footer>
    <!-- Footer --><?php /**PATH C:\Users\zaenur\Documents\dev\freelance\photo_studio\resources\views/partials/user-footer.blade.php ENDPATH**/ ?>