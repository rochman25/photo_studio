
<?php $__env->startPush('styles'); ?>
    <!--begin::Page Vendors Styles(used by this page) -->
    <link href="<?php echo e(asset('admin_asset/assets/plugins/custom/fullcalendar/fullcalendar.bundle.css')); ?>" rel="stylesheet"
        type="text/css" />
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('pages'); ?>
    <!-- begin:: Subheader -->
    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-container  kt-container--fluid ">
            <div class="kt-subheader__main">
                <h3 class="kt-subheader__title">
                    <?php echo e('Jadwal Booking'); ?> </h3>
                <span class="kt-subheader__separator kt-hidden"></span>
            </div>
            <div class="kt-subheader__toolbar">
                <div class="kt-subheader__wrapper">
                    <div class="dropdown dropdown-inline" data-toggle="kt-tooltip" title="Tambah Data"
                        data-placement="left">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end:: Subheader -->
    <div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
        <div class="row">
            <div class="col-lg-12">

                <!--begin::Portlet-->
                <div class="kt-portlet" id="kt_portlet">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <span class="kt-portlet__head-icon">
                                <i class="flaticon-map-location"></i>
                            </span>
                            <h3 class="kt-portlet__head-title">
                                Jadwal Booking
                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body">
                        <p><span class="badge badge-success">Accept (acc)</span> => Menandakan bahwa data booking sudah <b>di terima</b> oleh admin.</p>
                        <p><span class="badge badge-warning">Pending (pending)</span> => Menandakan bahwa data booking <b> belum di proses</b> oleh admin.</p>
                        <p><span class="badge badge-danger">Cancel (cancel)</span> => Menandakan bahwa data booking <b>di batalkan</b> oleh admin.</p>
                        <div id="kt_calendar"></div>
                    </div>
                </div>

                <!--end::Portlet-->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

    <!--begin::Page Vendors(used by this page) -->
    <script src="<?php echo e(asset('admin_asset/assets/plugins/custom/fullcalendar/fullcalendar.bundle.js')); ?>"
        type="text/javascript"></script>

    <!--end::Page Vendors -->
    
    
    
    <!--begin::Page Scripts(used by this page) -->
    <script src="<?php echo e(asset('admin_asset/assets/js/pages/components/calendar/basic.js')); ?>" type="text/javascript"></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zaenur\Documents\dev\freelance\photo_studio\resources\views/pages/admin/schedule/index.blade.php ENDPATH**/ ?>