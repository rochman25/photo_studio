
<?php $__env->startSection('user_pages'); ?>
    <main id="main">

        <!-- ======= Breadcrumbs Section ======= -->
        <section class="breadcrumbs">
            <div class="container">

                <div class="d-flex justify-content-between align-items-center">
                    <h2>Produk</h2>
                    <ol>
                        <li><a href="<?php echo e(route('view.user.shop')); ?>">Shop</a></li>
                        <li><?php echo e($product->nama); ?></li>
                    </ol>
                </div>

            </div>
        </section><!-- End Breadcrumbs Section -->

        <section class="portfolio-details">
            <div class="container">

                <div class="portfolio-details-container">

                    <div class="owl-carousel portfolio-details-carousel">
                        <img src="<?php echo e(asset($product->thumbnail)); ?>" class="img-fluid" alt="">
                        
                    </div>

                    <div class="portfolio-info">
                        <h3>Informasi Produk</h3>
                        <ul>
                            <li><strong>Kategori</strong>: <?php echo e($product->category->nama); ?></li>
                            <li><strong>Harga</strong>: Rp. <?php echo e(number_format($product->harga)); ?></li>
                        </ul>
                        <a href="<?php echo e(route('get.add_to_cart',$product->id)); ?>" class="btn btn-secondary btn-md" style="width: 100%">PESAN</a>
                    </div>

                </div>

                <div class="portfolio-description">
                    <h2><?php echo e($product->nama); ?></h2>
                    <p>
                        <?php echo $product->deskripsi; ?>

                    </p>

                </div>
            </div>
        </section><!-- End Portfolio Details Section -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zaenur\Documents\dev\freelance\photo_studio\resources\views/pages/user/shop/detail.blade.php ENDPATH**/ ?>