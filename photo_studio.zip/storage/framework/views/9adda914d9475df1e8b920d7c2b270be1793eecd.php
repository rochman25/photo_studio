
<?php $__env->startSection('pages'); ?>
    <!-- begin:: Subheader -->
    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-container  kt-container--fluid ">
            <div class="kt-subheader__main">
                <h3 class="kt-subheader__title">
                    <?php echo e('Order Booking'); ?> </h3>
                <span class="kt-subheader__separator kt-hidden"></span>
            </div>
            <div class="kt-subheader__toolbar">
                <div class="kt-subheader__wrapper">
                    <div class="dropdown dropdown-inline" data-toggle="kt-tooltip" title="Tambah Data"
                        data-placement="left">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end:: Subheader -->
    <div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid" style="margin-top:0px">
        <div class="row">
            <div class="col-xl-12">
                <!--begin::Portlet-->
                <div class="kt-portlet">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                Data Order Booking
                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body">

                        <!--begin::Section-->
                        <div class="kt-section">
                            <div class="kt-section__content">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Username</th>
                                            <th>Waktu</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php ($no = 1); ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <th scope="row"><?php echo e($no); ?></th>
                                                <td><?php echo e($item->user->name); ?></td>
                                                <td><?php echo 'Tanggal: ' . \Carbon\Carbon::parse($item->tanggal_booking)->format('d-m-Y') . '<br/> Pukul : ' . $item->waktu_booking; ?></td>
                                                <td><?php echo e($item->status); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('booking.show', $item->id)); ?>"
                                                        class="btn btn-sm btn-info"><i class="fa fa-info"></i> Detail</a>
                                                    <?php if(Auth::user()->role->role->name == 'super_admin'): ?>
                                                        <?php if($item->status != 'acc'): ?>
                                                            <button type="button"
                                                                data-url="<?php echo e(route('booking.order.accept', $item->id)); ?>"
                                                                data-status="Menerima"
                                                                class="btn btn-sm btn-success btn-hapus"><i
                                                                    class="fa fa-check"></i>Terima
                                                            </button>
                                                        <?php endif; ?>

                                                        <?php if($item->status != 'cancel'): ?>
                                                            <button type="button"
                                                                data-url="<?php echo e(route('booking.order.cancel', $item->id)); ?>"
                                                                data-status="Membatalkan"
                                                                class="btn btn-sm btn-danger btn-hapus"><i
                                                                    class="fa fa-window-close"></i> Batal
                                                            </button>
                                                        <?php endif; ?>

                                                    <?php else: ?>
                                                        <?php if($item->status != 'cancel' && $item->status == 'pending'): ?>
                                                            <button type="button"
                                                                data-url="<?php echo e(route('booking.order.cancel', $item->id)); ?>"
                                                                data-status="Membatalkan"
                                                                class="btn btn-sm btn-danger btn-hapus"><i
                                                                    class="fa fa-window-close"></i> Batal
                                                            </button>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!--end::Section-->
                        </div>

                        <!--end::Form-->
                    </div>

                    <!--end::Portlet-->
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            $(document).ready(function() {
                $('.btn-hapus').click(function() {
                    // alert("Hapus fired.")
                    const url = $(this).data('url');
                    const idBtn = $(this).data('id');
                    const status = $(this).data('status');
                    swal.fire({
                        title: "Konfirmasi",
                        text: "Apakah anda yakin ingin " + status + " Order ini ?",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Ya',
                        cancelButtonText: 'Tidak',
                        reverseButtons: true,
                    }).then(function(result) {
                        if (result.value) {
                            $.ajax({
                                url: url,
                                type: "POST",
                                data: {
                                    _token: "<?php echo e(csrf_token()); ?>",
                                    id: idBtn
                                },
                                success: function(response) {
                                    console.log(response)
                                    if (response.success) {
                                        swal.fire("Sukses!",
                                            "Data Order berhasil diubah", "success");
                                        setTimeout(location.reload.bind(location), 1000);
                                    } else {
                                        swal("Error", "Maaf terjadi kesalahan", "error");
                                    }
                                }
                            });
                        } else {
                            swal.close();
                        }
                    });
                });
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zaenur\Documents\dev\freelance\photo_studio\resources\views/pages/admin/booking/index.blade.php ENDPATH**/ ?>