@extends('errors::custom')

@section('title', __('Not Found'))
@section('code', '404')
@section('message', __("Sorry we can't seem to find the page you're looking for."))
