<div class="kt-container kt-container--fluid ">
    <div class="kt-footer__copyright">
        2021&nbsp;&copy;&nbsp;<a href="http://keenthemes.com/metronic" target="_blank" class="kt-link"></a>
    </div>
</div>
