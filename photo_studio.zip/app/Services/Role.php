<?php

class Role {
}