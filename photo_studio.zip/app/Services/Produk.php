<?php

namespace App\Services;

use App\Models\Product;

class Produk {

    public function __construct()
    {
        
    }

    

}