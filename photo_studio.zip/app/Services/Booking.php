<?php

namespace App\Services;

class Booking {

}